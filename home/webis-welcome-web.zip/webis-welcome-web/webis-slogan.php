<?php
$picture_path = "http://www.uni-weimar.de/cms/fileadmin/medien/webis/home/";
?>

<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans">

<style type="text/css">
      #signature{
      display:none;
      }

      #wrapper{
      line-height: 1;
      }

      #background{
      background-image: url("<?=$picture_path."webis-slogan-".rand(1,3);?>.jpg");
      background-repeat: no-repeat;
      background-position: right top;
      position: relative;
      width: 800px;
      height: 415px;
      }

      #slogan{
      font-family: 'Droid Sans', arial, serif;
      color: #fff;
      position: absolute;
      bottom: 5px;
      left: 0px;
      width: 800px;
      }

      #sloganCopy{
      background-color: rgb(1,124,112);
      font-size: 11px;
      float: left;
      padding: 1px;
      vertical-align: middle;
      margin-top: 13px;
      }

      #sloganText {
      font-size: 30px;
      float: right;
      margin-right: 10px;
     }
</style>

<script type="text/javascript">
     $(document).ready(function(){
          $("#slogan").hide().delay(1000).fadeIn(1000);
     });
</script>

<div id="wrapper">
  <div id="background">
    <div id="slogan">
      <div id="sloganCopy">&copy; www.webis.de 2005-2012</div>
      <div id="sloganText">Information is nothing without Retrieval</div>
    </div>
  </div>
</div>
