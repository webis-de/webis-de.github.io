/****************************************************************************
* domain-permuter.c
* Steven Burrows
* 3 September 2012 
*
* Creates a large number of domain definition files.
* The number of files is defined by the following argument:
*
* 1. EXTENSION_MODE == EXTENSION_MODE_UNIFORM
* The boundaries are adjusted uniformly. 
* files = "rows" * "columns" * ("numDeltasPerDirection" * 2 - 1)
* For example:
* 192 = 8 * 8 * (2 * 2 - 1)
*
* 2. EXTENSION_MODE == EXTENSION_MODE_IRREGULAR
* The boundaries are extentended in all possible combinations.
* files = "rows" * "columns" * ("num-deltas-per-direction" ^ 4)
* For example:
* 1024 = 8 * 8 * (2 ^ 4)
*
* Example:
*                                           >> east adjustment
*                                 +--------+   
*                                               ^ north adjustment
*                              +  +--------+  +
*                              |  |        |  |
*                              |  |  sub-  |  |
*                              |  | domain |  |
*                              |  |        |  |
*                              +  x--------+  +
*           south adjustment v
*                                 +--------+
*               west adjustment <<
*   
****************************************************************************/ 

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EXTENSION_MODE_UNIFORM 1
#define EXTENSION_MODE_IRREGULAR 2


/****************************************************************************
* usage()
* Prints usage information then terminates when incorrect usage is given.
****************************************************************************/ 
void usage(char* message)
{
   fprintf(stderr, "%s\n", message);
   fprintf(stderr, "Usage:\n");
   fprintf(stderr, "./domain-permuter <rows> <columns> <start-size> ");
   fprintf(stderr, "<delta-size> <num-deltas-per-direction>\n");
   fprintf(stderr, "Example:\n");
   fprintf(stderr, "./domain-permuter 4 4 0.004 0.002 2\n");
   fprintf(stderr, "Exiting...\n");
   exit(EXIT_FAILURE);
}


/****************************************************************************
* processCmdArgs()
* Checks the number and contents of the command line arguments.
****************************************************************************/ 
void processCmdArgs(int argc, char* argv[], unsigned* rows, unsigned* cols,
   double* startSize, double* deltaSize, unsigned* numDeltasPerDirection)
{
   /* Define number of command line arguments. */
   const unsigned NUM_ARGS = 5;

   /* Check number of command line arguments. */
   if (argc != NUM_ARGS + 1)
   {
      usage("Incorrect number of command line arguments.");
   }

   /* Check first command line argument. */
   *rows = atoi(argv[1]);
   if (*rows <= 0)
   {
      usage("Incorrect <rows> argument.");
   }

   /* Check second command line argument. */
   *cols = atoi(argv[2]);
   if (*cols <= 0)
   {
      usage("Incorrect <columns> argument.");
   }

   /* Check third command line argument. */
   *startSize = atof(argv[3]);
   if (*startSize < 0.0)
   {
      usage("Incorrect <start-size> argument.");
   }

   /* Check fourth command line argument. */
   *deltaSize = atof(argv[4]);
   if (*deltaSize <= 0.0)
   {
      usage("Incorrect <delta-size> argument.");
   }

   /* Check fifth command line argument. */
   *numDeltasPerDirection = atof(argv[5]);
   if (*numDeltasPerDirection <= 0)
   {
      usage("Incorrect <num-deltas-per-direction> argument.");
   }
}


/****************************************************************************
* power()
* Calculates a power using unsigned integers. Nb: math.pow() uses doubles. 
****************************************************************************/ 
unsigned power(unsigned base, unsigned exponent)
{
   return (unsigned) pow((double) base, (double) exponent);
}


/****************************************************************************
* calculateSubdomainBoundaries()
* Calculates the boundaries of one sub-domain with deltas as necessary.
****************************************************************************/ 
void calculateSubdomainBoundaries(double* xmin, double* ymin, double* xmax,
   double* ymax, unsigned rows, unsigned cols, unsigned neighborhood,
   double deltaSize, unsigned numDelta, unsigned numDeltasPerDirection,
   unsigned applyDeltas, double startSize)
{
   /* Derive the coordinates for the current sub-domain. */
   *xmin = (neighborhood % cols    ) * (1.0 / rows) - startSize;
   *ymin = (neighborhood / cols    ) * (1.0 / cols) - startSize;
   *xmax = (neighborhood % cols + 1) * (1.0 / rows) + startSize;
   *ymax = (neighborhood / cols + 1) * (1.0 / cols) + startSize;

   /* Modify the boundaries if a desired sub-domain is found. */
   /* Only one sub-domain in the entire domain is modified. */
   /* Otherwise, do not modify any boundaries. */
   if (applyDeltas)
   {
#if EXTENSION_MODE == EXTENSION_MODE_UNIFORM
      /* The extension is uniform for all directions. */
      int middleDelta = numDeltasPerDirection * 2 - numDeltasPerDirection;
      double extension = ((int) numDelta + 1 - middleDelta) * deltaSize;

      /* North extension. */
      *ymax += extension;
      /* East  extension. */
      *xmax += extension;
      /* South extension. */
      *ymin -= extension;
      /* West  extension. */
      *xmin -= extension;

#elif EXTENSION_MODE == EXTENSION_MODE_IRREGULAR
      /* North extension. */
      *ymax += deltaSize * (numDelta / power(numDeltasPerDirection, 3)
         % numDeltasPerDirection);
      /* East  extension. */
      *xmax += deltaSize * (numDelta / power(numDeltasPerDirection, 2)
         % numDeltasPerDirection);
      /* South extension. */
      *ymin -= deltaSize * (numDelta / power(numDeltasPerDirection, 1)
         % numDeltasPerDirection);
      /* West extension.  */
      *xmin -= deltaSize * (numDelta / power(numDeltasPerDirection, 0)
         % numDeltasPerDirection);

#endif
   }
}


/****************************************************************************
* printSubdomains()
* Prints one combination of sub-domains.
* The delta change is applied to one specific row, column and direction only.
****************************************************************************/ 
void printSubDomains(unsigned row, unsigned rows, unsigned col,
   unsigned cols, unsigned numDelta, unsigned numDeltasPerDirection,
   double deltaSize, double startSize, unsigned cell, unsigned fCount)
{
   /* Number of neighborhoods. */
   unsigned neighborhoods = rows * cols;

   /* Current neighborhood being processed. */
   unsigned neighborhood;
   unsigned applyDeltas;  /* Boolean type. 1: True. 0: False. */

   /* Coordinates of corners of the current sub-domain. */
   double xmin, xmax, ymin, ymax;

   /* File processing variables. */
   FILE* fpOut;
   char filename[FILENAME_MAX + 1];
   /*char tmp[FILENAME_MAX + 1];*/
   /*unsigned numFilesDigits;*/

   /* Prepare the filename. */
   /*numFilesDigits = sprintf(tmp, "%d",
      rows * cols * power(numDeltasPerDirection, 4));*/
   /*sprintf(filename, "output/domain.%0*d.%d.%d.%d.%d.txt", numFilesDigits,
      fCount, cell + 1, row + 1, col + 1, numDelta + 1);*/
   sprintf(filename, "output/domain.%06d.%d.%d.%d.%d.txt",
      fCount, cell + 1, row + 1, col + 1, numDelta + 1);

   /* Open the file, and terminate on failure. */
   if ((fpOut = fopen(filename, "w")) == NULL)
   {
      fprintf(stderr, "Could not open file '%s'. Exiting...\n", filename);
      exit(EXIT_FAILURE);
   }

   /* Process all lines of one domain definition file. */
   for (neighborhood = 0; neighborhood < neighborhoods; neighborhood++)
   {
      /* Determine if the current sub-domain should have delta changes. */
      /* Literals "1" and "0" represent "true" and "false" respectively. */
      applyDeltas = neighborhood == row * rows + col ? 1 : 0;

      /* Calculate the coordinates for the current sub-domain. */
      calculateSubdomainBoundaries(&xmin, &ymin, &xmax, &ymax,
         rows, cols, neighborhood, deltaSize, numDelta,
         numDeltasPerDirection, applyDeltas, startSize);

      /* Output the coordinates for the current sub-domain. */
      fprintf(fpOut, "%.3f %.3f %.3f %.3f\n", xmin, ymin, xmax, ymax);
   }

   /* Close the file when finished. */
   fclose(fpOut);
}


/****************************************************************************
* main()
* Driver function.
****************************************************************************/ 
int main(int argc, char* argv[])
{
   /* Variables for holding data accepted from the command line. */
   unsigned rows;
   unsigned cols;
   double startSize;
   double deltaSize;
   unsigned numDeltasPerDirection;

   /* Derived variable. */
   unsigned numDeltas;

   /* Loop control variables. */
   unsigned row;
   unsigned col;
   unsigned cell;
   unsigned numDelta;
   unsigned fCount = 1;

   /* Process the command line arguments. */
   processCmdArgs(argc, argv, &rows, &cols,
      &startSize, &deltaSize, &numDeltasPerDirection);

   /* Calculate the numDeltas derived variable. */
#ifdef EXTENSION_MODE
#if EXTENSION_MODE == EXTENSION_MODE_UNIFORM
   numDeltas = numDeltasPerDirection * 2 - 1;
#elif EXTENSION_MODE == EXTENSION_MODE_IRREGULAR
   numDeltas = power(numDeltasPerDirection, 4);
#else
   fprintf(stderr, "Error: Variable 'EXTENSION_MODE' invalid.\n", message);
   return EXIT_FAILURE;
#endif
#else
   fprintf(stderr, "Error: Variable 'EXTENSION_MODE' undefined.\n", message);
   return EXIT_FAILURE;
#endif

   /* Iterate over all combinations of output files created. */
   for (row = 0, cell = 0; row < rows; row++)
   {
      for (col = 0; col < cols; col++, cell++)
      {
         for (numDelta = 0; numDelta < numDeltas; numDelta++, fCount++)
         {
            printSubDomains(row, rows, col, cols, numDelta,
               numDeltasPerDirection, deltaSize, startSize, cell, fCount);
         }
      }
   }

   /* End of program. */
   return EXIT_SUCCESS;
}

