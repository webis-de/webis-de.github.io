readme.txt
21 September 2012

This file describes supporting code modules for the following paper:
Steven Burrows, Joerg Frochte, Michael Voelske, Ana Belen Martnez Torres and Benno Stein.
Overlap Optimization by Machine Learning for Domain Decomposition Methods. In submission.


(1) LIBRARY INSTALLATION

- Folder "meml-0.7.2": Run "install.sh".
- Folder "ffep-0.8.3": Run "install.sh".


(2) SOFTWARE

- "addschwarz": Run "make" and "make run" to conduct a simulation.
- "diffusion-permuter": Run "make" and "make run" to generate diffusion specifications.
- "domain-permuter": Run "make" and "make run" to generate domain specifications.

