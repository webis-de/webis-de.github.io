tar xzf meml-0.7.2.tar.gz
cd meml-0.7.2/src/
cat disl.h | sed 's/^#include "umfpack.h"$/#include "suitesparse\/umfpack.h"/g' > disl.h.tmp && mv disl.h.tmp disl.h
cd ..
./configure --prefix=$HOME/local CFLAGS="-Wall -W -O2 $CFLAGS -D__HAVE_UMFPACK"
make
make install
cd ..
rm -rf meml-0.7.2
