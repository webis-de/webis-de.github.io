tar xzf ffep-0.8.3.1.tar.gz
cd ffep-0.8.3
./configure --prefix=$HOME/local CFLAGS="-Wall -W -O2 $CFLAGS -I $HOME/local/include/"
make
make install
cd ..
rm -rf ffep-0.8.3
