#include <limits.h> 
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <time.h>
#include "ffep.h"
#include "suitesparse/umfpack.h"

#ifdef __HAVE_OPENMP
#include <omp.h>
#endif

#ifndef MYTHREADS
#define MYTHREADS 4
#endif

#ifndef DOFLINE
#define DOFLINE 501
#endif

char * domainfile;
char * diffusionfile;
char * outfile;
char * solutionfile;

double rx1,ry1,rx2,ry2,neweps;
double cx1,cy1,cr;


int pharseArgs(int argc, char * const argv[])
{

  if ( (argc!=7) && (argc!=5) && (argc!=1) )
    {
      fprintf(stderr,"Please use the floowing form:\n");
      fprintf(stderr,"./addschwarz <domain-file> <diffusion-file> <output-file> <solution-file> [--max-iterations NUMBER]\n");
      exit(0);
    }
  else if ( argc==1 )
    {
      domainfile = (char *) calloc(256,sizeof(char));
      strcpy(domainfile, "domaindef.txt");
      diffusionfile = (char *) calloc(256,sizeof(char));
      strcpy(diffusionfile, "diffusiondef.txt");
      outfile = (char *) calloc(256,sizeof(char));
      strcpy(outfile, "output.txt");
      solutionfile = (char *) calloc(256,sizeof(char));
      strcpy(solutionfile, "solu.dat");
    }
  else
    {
      domainfile = argv[1];
      diffusionfile  = argv[2];
      outfile   = argv[3];
      solutionfile = argv[4];
    }

  if ( argc==7 )
    {
      int temp = atoi(argv[6]);
      return(temp);
    }

  return(INT_MAX);
}



MESH * submesh(MESH * mesh, VECTOR * points, ME_MATRIX **big2small,ME_MATRIX **small2big,
	       VECTOR *gewicht)
{
  MESH * newmesh;
  INDEXARRAY * tri; 
  INDEXARRAY * newpoints; 
  INDEXARRAY * oldpoints; 
  INDEXARRAY * dreiecke; 
  INDEXARRAY * triangles; 
  VECTOR *coord;
  int i,j,k, pzaehler=0, tzaehler=0;
  int fin;

  /* mapping der neuen punkte auf die alten */
  newpoints = meml_indexarray_new(points->dim);
  /* mapping der alten punkte auf die neuen */
  oldpoints = meml_indexarray_new(points->dim);
  dreiecke  = meml_indexarray_new(mesh->number_of_triangles);

  for (i=0;i<points->dim;i++)
    {
      if (points->data[i] == 1)
	{
	  oldpoints->data[i]=pzaehler;
	  newpoints->data[pzaehler++]=i;
	}
      else
	{
	  oldpoints->data[i]=-1;
	}
    }

  fin=pzaehler;
  for (i=0;i<fin;i++)
    {
      int * temp; 
      int zugriff=newpoints->data[i];

      tri = mesh->point2triangle[zugriff];

      for (j=0;j<tri->dim;j++)
	{
	  /* dreieck gehoert dazu */
	  if (dreiecke->data[tri->data[j]] != 1)
	    {
	      tzaehler++;
	      dreiecke->data[tri->data[j]] = 1;
	    }
	  temp = mesh->triangles->data; 

	  /* ggf. fehlende Punkte ergaenzen */
	  for (k=0;k<3;k++)
	    {
	     int foo = temp[3*tri->data[j] + k];

	     if (oldpoints->data[foo-1] == -1)
	       {
		 oldpoints->data[foo-1]=pzaehler;
		 newpoints->data[pzaehler++]=foo-1;
	       }
	    }
	}
    }

  triangles = meml_indexarray_new(3*tzaehler);

  coord = meml_vector_new(2*pzaehler);

  tzaehler=0;

  for (i=0;i<dreiecke->dim;i++)
    {
      if ( dreiecke->data[i] == 1 ) 
	{
	  for (j=0;j<3;j++)
	    {
	      int temp = mesh->triangles->data[3*i+j];
	      int newone = oldpoints->data[temp-1];

	      triangles->data[3*tzaehler+j] = newone+1; 
	      coord->data[2*(newone)] = mesh->points->data[2*(temp-1)];
	      coord->data[2*(newone)+1] = mesh->points->data[2*(temp-1)+1];
	    }
	  tzaehler++;
	}
    }

  newmesh=smfl_mesh_new('l',NULL,coord,triangles);

  (*big2small) = meml_matrix_new(LS, coord->dim/2, points->dim);
  
  for (i=0;i<coord->dim/2;i++)
    {
      meml_matrix_element_set(*big2small,i,newpoints->data[i],1);
    }

  (*small2big) = meml_matrix_new(LS, points->dim, coord->dim/2);

  for (i=0;i<points->dim;i++)
    {
      if (oldpoints->data[i] != -1 )
	{
	  int j; 
	  int wertneuerpunkt = oldpoints->data[i] +1;
	  char controlle=0;

	  for (j=0;j<newmesh->boundary->dim;j++)
	    {
	      int randpunkt = newmesh->boundary->data[j];

	      if (wertneuerpunkt == randpunkt)
		{
		  controlle=1;
		  break;
		}
	    }

	  if (controlle==0)
	    {
	      meml_matrix_element_set(*small2big,i,oldpoints->data[i],1);
	      gewicht->data[i]++;
	    }
	}
    }

  meml_vector_free(coord);
  meml_indexarray_free(triangles);
  meml_indexarray_free(dreiecke);
  meml_indexarray_free(newpoints);
  meml_indexarray_free(oldpoints);

  return(newmesh);
}


double func_rectangle (double x, double y, double t)
{
  double temp;

  temp = 0;

  if ( (x>=rx1) && (x<=rx2) )
    if ( (y>=ry1) && (y<=ry2) )
      temp =neweps;
  
  return (temp);
}

double func_circle (double x, double y, double t)
{
  double temp;
  double dist;

  dist=(x-cx1)*(x-cx1)+(y-cy1)*(y-cy1);

  if (dist < cr*cr)
    temp = neweps;
  else
    temp = 0;

  return (temp);
}


VECTOR * read_domains()
{
  FILE *DATA;
  long int LINE = 100000;
  char line[LINE];
  char *lineptr;
  char *filename=domainfile;
  VECTOR * temp;
  int counter=0;
  
  temp = meml_vector_new(1);

  DATA = fopen (filename, "r");
  
  if (DATA == NULL)
    {
      fprintf (stderr, "Could not open %s for reading!\n", filename);
      exit (0);
    }

  while (NULL != fgets (line, LINE, DATA))
    {
      lineptr = line;
      counter++;
      vecl_vector_resize_f (temp, counter*4);
      temp->data[4*(counter-1)] = (double) strtod (lineptr, &lineptr);
      temp->data[4*(counter-1) +1] = (double) strtod (lineptr, &lineptr);
      temp->data[4*(counter-1) +2] = (double) strtod (lineptr, &lineptr);
      temp->data[4*(counter-1) +3] = (double) strtod (lineptr, &lineptr);
  
      if ( !(temp->data[4*(counter-1)] < temp->data[4*(counter-1) +2]) )
	{
	  printf(" x1 must be smaller than x2! Please check the domain file.\n");
	  fclose (DATA);
	  exit(EXIT_FAILURE);
	}

      if ( !(temp->data[4*(counter+1)] < temp->data[4*(counter-1) +3]) )
	{
	  printf(" y1 must be smaller than y2! Please check the domain file.\n");
	  fclose (DATA);
	  exit(EXIT_FAILURE);
	}
  }
  
  fclose (DATA);

  return(temp);
}


void read_extern_def(MESH * mesh, VECTOR * myeps)
{
  FILE *DATA;
  long int LINE = 100000;
  char line[LINE];
  char *lineptr;
  char *filename = diffusionfile;
  VECTOR * temp;
  int i;
  
  DATA = fopen (filename, "r");
  
  if (DATA == NULL)
    {
      fprintf (stderr, "Could not open %s for reading!\n", filename);
      exit (0);
    }

  while (NULL != fgets (line, LINE, DATA))
    {
      lineptr = line;
      if (line[0]=='r')
	{
	  lineptr++;
	  rx1 = (double) strtod (lineptr, &lineptr);
          ry1 = (double) strtod (lineptr, &lineptr);
          rx2 = (double) strtod (lineptr, &lineptr);
          ry2 = (double) strtod (lineptr, &lineptr);
          neweps = (double) strtod (lineptr, &lineptr);

	  temp=lfel_apply_function_to_vector(mesh,&func_rectangle,0);

	  if ( !(rx1 < rx2) )
	    {
	      printf(" rx1 must be smaller than rx2! Please check the diffusion file.\n");
	      fclose (DATA);
	      exit(EXIT_FAILURE);
	    }
	  
	  if ( !(ry1 < ry2) ) 
	    {
	      printf(" ry1 must be smaller than ry2! Please check the diffusion file.\n");
	      fclose (DATA);
	      exit(EXIT_FAILURE);
	    }	  

        }
      else if (line[0]=='c')
	{
	  lineptr++;
	  cx1 = (double) strtod (lineptr, &lineptr);
          cy1 = (double) strtod (lineptr, &lineptr);
          cr = (double) strtod (lineptr, &lineptr);
          neweps = (double) strtod (lineptr, &lineptr);

	  if ( !(0 < cr) )
	    {
	      printf("radius muss be >0!  Please check the diffusion file.\n");
	      fclose (DATA);
	      exit(EXIT_FAILURE);
	    }

	  temp=lfel_apply_function_to_vector(mesh, &func_circle,0);
        }
      else
	{
	  fprintf (stderr, "Syntax error in %s !\n", filename);
	  exit (0);
	}
      //vecl_vector_add_ff (1,temp,myeps);
  
      for (i=0;i<myeps->dim;i++)
	{
	  if (temp->data[i] != 0)
	    {
	      myeps->data[i] = temp->data[i];
	    }
	}

      meml_vector_free(temp);
    }
  
  fclose (DATA);
}


int main (int argc, char * const argv[])
{
  //INDEXARRAY * boundary; /* the boundary points */
  VECTOR * points; /* points of the triangulation */
  INDEXARRAY * triangles; /* the triangles of triangulation */
  VECTOR * solu, **solulocal;   /* the vector to store the solution */
  VECTOR *f;       /* the vector for the right side */
  ME_MATRIX *A,*B;   /* the galerkin matrix */
  VECTOR  * b, **blocal;     /* right side of Ax=b */
  MESH * mesh, **domainmesh;     
  VECTOR * bcound;   /* vector for Dirichlet boundary conditions */
  //  double  eps = 1.0; /* diffusion coefficient */ 
  VECTOR *eps; /* diffusion coefficient */ 
  /*LEGEND legende;*/
  int x,y,i,iterationen=0;
  ME_MATRIX **b2s,**s2b;
  VECTOR * domains, *gewicht; 
  VECTOR * localeps;
  ME_MATRIX **Alocal;   /* the galerkin matrix */
  double fehler;
  void *Symbolic, **Numeric;
  int **Ap;
  int **Ai;
  double **Ax;
  clock_t start, end;
  double cpu_time_used; 
  unsigned long int FlopEstimator=0;
  int maxiterations = INT_MAX;

#ifdef __HAVE_OPENMP
  omp_set_num_threads(MYTHREADS);
#endif


  maxiterations = pharseArgs(argc,argv);  

  meml_init(1e-16,'g',0);

  printf("build fullmesh data\n");
  
  //boundary=NULL;

  points=meml_vector_new(2*DOFLINE*DOFLINE);
  {
    double *p=points->data;
    int zaehler=0;

    for (y=0;y<DOFLINE;y++)
      {
	for (x=0;x<DOFLINE;x++)
	  {
	    p[zaehler++]=x*1.0/(DOFLINE-1);
	    p[zaehler++]=y*1.0/(DOFLINE-1);
	  }
      }
  }

  triangles=meml_indexarray_new(2*3*(DOFLINE-1)*(DOFLINE-1));
  {
    int zaehler=0;

    for (y=1;y<DOFLINE;y++)
      {
	for (x=0;x<DOFLINE-1;x++)
	  {	
	    triangles->data[zaehler++]=x+y*DOFLINE +1;
	    triangles->data[zaehler++]=x+(y-1)*DOFLINE +1;
	    triangles->data[zaehler++]=x+(y-1)*DOFLINE+1 +1;

	    triangles->data[zaehler++]=x+y*DOFLINE +1;
	    triangles->data[zaehler++]=x+y*DOFLINE+1 +1;
	    triangles->data[zaehler++]=x+(y-1)*DOFLINE+1 +1;
	  }
      }
  }

  printf("built fullmesh\n");
  mesh=smfl_mesh_new('l',NULL,points,triangles);
  meml_indexarray_free(triangles);
  meml_vector_free(points);

  printf("built partmesh\n");
  domains = read_domains();

  domainmesh = (MESH**) calloc(domains->dim/4,sizeof(MESH*));
  s2b = (ME_MATRIX**) calloc(domains->dim/4,sizeof(ME_MATRIX*));
  b2s = (ME_MATRIX**) calloc(domains->dim/4,sizeof(ME_MATRIX*));
  Alocal = (ME_MATRIX**) calloc(domains->dim/4,sizeof(ME_MATRIX*));
  blocal = (VECTOR**) calloc(domains->dim/4,sizeof(VECTOR*));
  solulocal = (VECTOR**) calloc(domains->dim/4,sizeof(VECTOR*));

  Numeric  = (void**) calloc(domains->dim/4,sizeof(void*));
  Ap  = (int**) calloc(domains->dim/4,sizeof(int*));
  Ai  = (int**) calloc(domains->dim/4,sizeof(int*));
  Ax   = (double**) calloc(domains->dim/4,sizeof(double*));


  gewicht = meml_vector_new(mesh->number_of_points);

#ifdef __HAVE_OPENMP
#pragma omp parallel 
  {
#pragma omp for schedule(static)
#endif
  for(i=0;i<domains->dim/4;i++)
  {
    VECTOR * p;

    rx1 = domains->data[4*i];
    ry1 = domains->data[4*i+1];
    rx2 = domains->data[4*i+2];
    ry2 = domains->data[4*i+3];
    neweps=1;

    p=lfel_apply_function_to_vector(mesh,&func_rectangle,0);

    domainmesh[i] = submesh(mesh,p, &(b2s[i]),&(s2b[i]),gewicht);
    
    meml_vector_free(p);
  }
#ifdef __HAVE_OPENMP
  }
#endif

  printf("number of unknowns : %d \n",mesh->number_of_points);

  /* define diffusion coeffizient */
  eps = meml_vector_new_ones(mesh->number_of_points);
  //  vecl_vector_scaling_f(0.001,eps);

  /*read extern eps defintion */
  read_extern_def(mesh,eps);


  /* ------------- buliding controll system start --------------- */
  /* homogeneous zero Dirichlet boundary conditions */
  bcound = meml_vector_new(mesh->number_of_points);

  /* right side */
  cr=10;cx1=0.5;cy1=0.5;neweps=4;
  f=lfel_apply_function_to_vector(mesh, func_circle,0);

  /* assembling A and b */

  B=meml_matrix_new(LS,mesh->number_of_points,mesh->number_of_points);
  lfel_assemb_diffusion_f(eps,B,mesh); 	
  A=meml_matrix_convert(CS,B);
  meml_matrix_free(B);
  b = lfel_assemb_right_side (f, mesh);
  meml_vector_free(f);

  /* plug-in the boundary conditions */
  lfel_set_dirichlet_boundary_cond(A,b,bcound,mesh);  
 /* ------------- buliding controll system end --------------- */

  printf("buliding local systems start\n");
  /* ------------- buliding local systems start --------------- */
  for(i=0;i<domains->dim/4;i++)
  {
    VECTOR * temp;
    f=lfel_apply_function_to_vector(domainmesh[i], func_circle,0);

    B=meml_matrix_new(LS,domainmesh[i]->number_of_points,domainmesh[i]->number_of_points);

    localeps = meml_matrix_vector_mul(b2s[i],eps);
    lfel_assemb_diffusion_f(localeps,B,domainmesh[i]); 
    meml_vector_free(localeps);
    Alocal[i] = meml_matrix_convert(CS,B);
    meml_matrix_free(B);
    blocal[i] = lfel_assemb_right_side (f,domainmesh[i]);

    temp = meml_vector_new(domainmesh[i]->number_of_points);
    lfel_set_dirichlet_boundary_cond(Alocal[i],blocal[i],temp,domainmesh[i]);  
    meml_vector_free(temp);

    Ap[i] = Alocal[i]->data.compressed_row->row;
    Ai[i] = Alocal[i]->data.compressed_row->column;
    Ax[i] = Alocal[i]->data.compressed_row->data;

    (void) umfpack_di_symbolic (Alocal[i]->row,Alocal[i]->col,
				Ap[i],Ai[i],Ax[i],
				&Symbolic,NULL,NULL);
  
    (void) umfpack_di_numeric (Ap[i],Ai[i],Ax[i],Symbolic,&(Numeric[i]),NULL,NULL);
    umfpack_di_free_symbolic(&Symbolic);

  }
  /* ------------- buliding local systems end --------------- */
  printf("buliding local systems end\n");

  start = clock(); 
  /* ------------- solving local systems start --------------- */
  printf("solving local systems start\n");
  solu = meml_vector_new(mesh->number_of_points);
  fehler=1;
  
  /* jjj */
  while ( (fehler>1e-6) && (iterationen<maxiterations) )
    {
      iterationen++;

      /* paraelle threads possible */
#ifdef __HAVE_OPENMP
#pragma omp parallel 
  {
#pragma omp for schedule(static)
#endif
      for(i=0;i<domains->dim/4;i++)
	{
	  VECTOR * temp;
	  temp = meml_matrix_vector_mul(b2s[i],solu);

	  lfel_set_dirichlet_boundary_cond(Alocal[i],blocal[i],temp,domainmesh[i]);  

	  meml_vector_free(temp);
	  /* solve the system with umfpack */
	  // solulocal[i]=disl_umfpack (Alocal[i],blocal[i]);

	  solulocal[i]=meml_vector_new(blocal[i]->dim);
	  (void) umfpack_di_solve(UMFPACK_At, Ap[i],Ai[i],Ax[i],solulocal[i]->data,blocal[i]->data,
				  Numeric[i],NULL,NULL);

	}
#ifdef __HAVE_OPENMP
  }
#endif
      meml_vector_free(solu);
      solu = meml_vector_new(mesh->number_of_points);
      /* paraelle threads end */
      for(i=0;i<domains->dim/4;i++)
	{
	  VECTOR * temp;
	  int j; 

	  temp = meml_matrix_vector_mul(s2b[i],solulocal[i]);
	  meml_vector_free(solulocal[i]);
	  for(j=0;j<mesh->number_of_points;j++)
	    {
	      if (gewicht->data[j] != 0)
		solu->data[j]=solu->data[j]+temp->data[j]/gewicht->data[j];
	    }
	  meml_vector_free(temp);
	}
 
      /* cal error */
      {
	VECTOR * temp;
	temp = meml_matrix_vector_mul(A,solu);
	vecl_vector_add_ff (-1,b,temp);
	fehler = meml_vector_norm_max(temp);
	meml_vector_free(temp);
	printf("%e \n",fehler);
	fflush(stdout);
      }
    }
  
  end = clock();
  cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
  printf("solving local systems end\n");

  if ( !(iterationen<maxiterations) )
    {
      char errorstring[]="The routine was interrupted because the maximum number of iterations was reached, but the error based stopping criterion was not met.";
      fprintf(stderr,"%s \n",errorstring);
      
      {
	FILE *DATA;
	char *filename = outfile;
  
	DATA = fopen (filename, "w");
	fprintf(DATA,"%s \n",errorstring);
      }
      exit(EXIT_FAILURE);
    }

  printf("writing data\n");
  {
    FILE *DATA;
    char *filename = outfile;
  
    DATA = fopen (filename, "w");
    
    if (DATA == NULL)
      {
	fprintf (stderr, "Could not open %s for writing!\n", filename);
	exit (0);
      }


    FlopEstimator=0;
    for(i=0;i<domains->dim/4;i++)
      {
	unsigned long int n = 
	  (unsigned long int) domainmesh[i]->number_of_points;

	FlopEstimator += n*n*n/3 + iterationen*n*n;
      }

    fprintf(DATA,"FLOP Estimator: %lu \n",FlopEstimator);
    fprintf(DATA,"%d iterations \n",iterationen);
    fprintf(DATA,"%e CPU Time used for solving. \n",cpu_time_used);
    
    {
      int zaehler=0;
      double prozent;
    
      for (i=1;i<gewicht->dim;i++)
	if ( (gewicht->data[i] != 0) && (gewicht->data[i] != 1) )
	  zaehler++;
      
      prozent = 100*((double)zaehler+gewicht->dim)/gewicht->dim;
      
      fprintf(DATA,"%d DoF in the domain\n",gewicht->dim);
      fprintf(DATA,"%d DoF in all overlap regions\n",zaehler);
      fprintf(DATA,"%lf %% size of the problem because of overlaps \n",prozent);

    }

    for(i=0;i<domains->dim/4;i++)
    {
      fprintf(DATA,"%d DoF in subdomain %d\n",domainmesh[i]->number_of_points,i);
    }

    fclose(DATA);
  
  }
  /* write the date to disk to visualise it in gnuplot */
  visl_write_gnuplotdata(solutionfile, mesh,solu); 

  printf("clean up\n");

  /* clean up */
  meml_vector_free(bcound);
  meml_vector_free(solu);
  meml_vector_free(b);
  meml_vector_free(eps);
  meml_matrix_free(A);
  smfl_mesh_free(mesh);  
  
  for(i=0;i<domains->dim/4;i++)
  {
    free(domainmesh[i]);
    free(s2b[i]);
    free(b2s[i]);
    free(Alocal[i]);
    free(blocal[i]);
    umfpack_di_free_numeric(&(Numeric[i]));
  }

  free(Alocal);
  free(blocal);
  free(Numeric);
  free(domainmesh);
  free(s2b);
  free(b2s);
  free(domains);
  free(solulocal);
  free(Ap);
  free(Ai);
  free(Ax);

  printf("FLOP Estimator: %lu\n", FlopEstimator);

  return(EXIT_SUCCESS);
}

