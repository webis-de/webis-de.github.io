/* Mersenne Twister C implementation; 
 * Source: http://en.literateprograms.org/Mersenne_twister_(C) 
 * Modified to accept arbitrary seed values, and to 32bit stdint types. */

/* This program implements the Mersenne twister algorithm for generation of pseudorandom numbers. 
The program returns random integers in the range 0 to 2^32-1 (this holds even if a long int is
larger than 32 bits). Timing with gcc indicates that it is about twice as fast as the built in 
rand function. The original code was written by Michael Brundage and has been placed in the 
public domain. There are a three minor changes here: 
(1) This comment has been added to the program.
(2) Type specifiers (ul) have been appended to constants.
(3) A commented out block near the end has been removed. */

#define MT_LEN 624
#include <stdlib.h>
#include <stdint.h>

#ifdef DEBUG
#include <stdio.h>
/* count number of random() calls for debug output */
unsigned long long call_num = 0;
#endif

int mt_index;
uint32_t mt_buffer[MT_LEN];

void mt_init(uint32_t seed) {
    int i;
    mt_buffer[0] = seed;
    for (i = 1; i < MT_LEN; i++) {
        mt_buffer[i] = 1812433253 *
          ((mt_buffer[i-1] ^ (mt_buffer[i-1] >> 30)) + i);
    }
    mt_index = 0;
}

#define MT_IA           397
#define MT_IB           (MT_LEN - MT_IA)
#define UPPER_MASK      0x80000000
#define LOWER_MASK      0x7FFFFFFF
#define MATRIX_A        0x9908B0DF
#define TWIST(b,i,j)    ((b)[i] & UPPER_MASK) | ((b)[j] & LOWER_MASK)
#define MAGIC(s)        (((s)&1)*MATRIX_A)

uint32_t mt_random() {
    uint32_t * b = mt_buffer;
    int idx = mt_index;
    uint32_t s;
    int i;

#ifdef DEBUG
    fprintf(stderr, "<<%d>> idx=%d\t", call_num++, idx);
#endif

    if (idx == MT_LEN*sizeof(uint32_t))
    {
#ifdef DEBUG
      fprintf(stderr, " <T> ");
#endif
        idx = 0;
        i = 0;
        for (; i < MT_IB; i++) {
            s = TWIST(b, i, i+1);
            b[i] = b[i + MT_IA] ^ (s >> 1) ^ MAGIC(s);
        }
        for (; i < MT_LEN-1; i++) {
            s = TWIST(b, i, i+1);
            b[i] = b[i - MT_IB] ^ (s >> 1) ^ MAGIC(s);
        }

        s = TWIST(b, MT_LEN-1, 0);
        b[MT_LEN-1] = b[MT_IA-1] ^ (s >> 1) ^ MAGIC(s);
    }
    mt_index = idx + sizeof(uint32_t);
#ifdef DEBUG
    fprintf(stderr, "\tidx=%d result=%u\n", mt_index, *(uint32_t *)((unsigned char *)b + idx));
#endif
    return *(uint32_t *)((unsigned char *)b + idx);
    /* Here there is a commented out block in MB's original program */
}
