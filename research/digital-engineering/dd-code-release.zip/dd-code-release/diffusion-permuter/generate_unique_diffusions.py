#!/usr/bin/python
# driver script that instruments the diffusion generation and eliminates
# duplicates

from os import remove, rename, path, system
from sys import argv, stderr, exit
from hashlib import md5 as hash_func
from glob import glob

DEBUG=False

out_dir = "output"
program = "./diffusion-permuter"

# number of output files to generate; default 100
count = len(argv) > 1 and int(argv[1]) or 100

# check that output directory exists
if not path.isdir(out_dir):
    stderr.write("Placeholder directory 'output' was not found. "
            "Please update your local filesystem from CVS.\n")
    exit(1)


# delete diffusion files from previous runs, if any
filter(remove, glob(path.join(out_dir, "diffusion.*.txt")))


# run the diffusion generation program
# (with 20% more diffusions than needed)
system("%s %d" % (program, 1.2 * count))


def decrement_name(fn, by):
    """
    Computes new file name if duplicates have been deleted.

    fn: orginal file name
    by: number of duplicates found previously
    """
    parts = fn.split(".")
    dg = len(parts[1])
    parts[1] = "%0*d" % (dg, int(parts[1]) - by)
    return ".".join(parts)



seen = set() # stores hash set of diffusions to find duplicates
duplicates = 0
kept = 0
# iterate over diffusion files in sorted order
for fn in sorted(glob(path.join(out_dir, "diffusion.*.txt"))):
    if DEBUG: stderr.flush()
    if kept >= count:
        # skip remaining files if we have enough
        if DEBUG: stderr.write("del:%s\n"%fn)
        remove(fn)
        continue
    h = hash_func()
    # compute hash on file contents
    # sort lines before hashing, to detect duplicates where the same
    # objects occur in permutation
    h.update("".join(sorted(open(fn).readlines())))
    h = h.digest()
    if h in seen:
        # delete file if we have seen one with the same hash before
        if DEBUG: stderr.write("del:%s\n"%fn)
        duplicates += 1
        remove(fn)
    else:
        # otherwise, store the hash, and update the file name as necessary
        kept += 1
        seen.add(h)
        rename(fn, decrement_name(fn, duplicates))
        if DEBUG and fn != decrement_name(fn, duplicates):
            stderr.write("mv:%s,%s\n"%(fn, decrement_name(fn,duplicates)))

stderr.write("removed %d duplicates.\n" % duplicates)
