#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <arpa/inet.h>
#include "mersenne_rand.h"

/**
 * Test program for mersenne_rand
 */
int main(int argc, char** argv) {
  mt_init(32798327);
  int i, shift;
  int count;
  uint32_t num;

  if(argc > 1) {
    /*
     * writes argv[1] dieharder-formatted ascii random numbers to stdout
     */
    count = atoi(argv[1]);
    fprintf(stdout, "type: d\ncount: %d\nnumbit: 32\n", count);
    for(i=0; i<count; i++) {
      num = mt_random();
      fprintf(stdout, "%u\n", num);
    }
  } else {
    /*
     * writes raw random byte stream to stdout
     */
    shift = 8*(sizeof(uint32_t) - 1);
    while (1) {
      num = mt_random();
      //num = 0xabcd2342;
      num = htonl(num);
      for(i=sizeof(uint32_t)-1;i>=0;i--) {
        /* e.g 1234 << 0
         *     1234 >> 3
         *     ---1
         *     1234 << 1
         *     234- >> 3
         *     ---2
         *     etc
         * */
        fprintf(stdout, "%c", (num << 8*i) >> shift);
      }
    }
  }
}
