#include <stdio.h>
#include <stdlib.h>
#include "mersenne_rand.h"
#define START 32798327
FILE *fcontrol;
FILE *diffusionfile;

int modul = 101;
int a = 61, b = 0;
int ynew;

int value() {
    int v;
    v = (mt_random() % 100 + 1) * 100;
    return (v);
}

int
ComputeRectangle(int zx, int zy, int gx, int gy,
        double *llx, double *lly, double *urx, double *ury) {
    *llx = (double) (zx - gx) / 100;
    *lly = (double) (zy - gy) / 100;
    *urx = (double) (zx + gx) / 100;
    *ury = (double) (zy + gy) / 100;

    if ( (*llx == *urx) || (*lly == *ury))  
      {
	fprintf(stderr,"A Rectangle whose width or height is exactly zero has location\n");
	fprintf(stderr,"Stopping diffusion file generation, please concated the developer\n");
	return(EXIT_FAILURE);
      }

    return EXIT_SUCCESS;
}

int 
ComputeCircle(int zx, int zy, int gx, int gy,
        double *szx, double *szy, double *srx) 
{
  *szx = (double) zx / 100;
  *szy = (double) zy / 100;
  *srx = (double) gx / 100;

  if ( !(*srx>0) )
    {
      fprintf(stderr,"A Cirvle whose radius is exactly zero has location\n");
      fprintf(stderr,"Stopping diffusion file generation, please concated the developer\n");
      return(EXIT_FAILURE);
    }

  return EXIT_SUCCESS;
}

void PseudorandInit() {
    mt_init(START);
}

int Pseudorand() {
    int ynew;
    /* A number [1-100] */
    ynew = mt_random() % 100 + 1;
    return (ynew);
}

int scale(int up, int to, int oldvalue) {
    int result;
    result = up + (to - up) * oldvalue / 100;
    return (result);
}

void regiondefinition(int region, int *Lxup, int *Lxdown, int *Lyup,
        int *Lydown) {
    /* nine regions, see appendix */
    switch (region) {
        case 0:
            *Lxup = 89;
            *Lxdown = 10;
            *Lyup = 89;
            *Lydown = 10;
            break;
        case 1:
            *Lxup = 89;
            *Lxdown = 10;
            *Lyup = 9;
            *Lydown = 0;
            break;
        case 2:
            *Lxup = 99;
            *Lxdown = 90;
            *Lyup = 89;
            *Lydown = 10;
            break;
        case 3:
            *Lxup = 89;
            *Lxdown = 10;
            *Lyup = 99;
            *Lydown = 90;
            break;
        case 4:
            *Lxup = 9;
            *Lxdown = 0;
            *Lyup = 89;
            *Lydown = 10;
            break;
        case 5:
            *Lxup = 9;
            *Lxdown = 0;
            *Lyup = 99;
            *Lydown = 90;
            break;
        case 6:
            *Lxup = 99;
            *Lxdown = 90;
            *Lyup = 99;
            *Lydown = 90;
            break;
        case 7:
            *Lxup = 99;
            *Lxdown = 90;
            *Lyup = 9;
            *Lydown = 0;
            break;
        case 8:
            *Lxup = 9;
            *Lxdown = 0;
            *Lyup = 9;
            *Lydown = 0;
            break;
    }
}

int
Dimensionx(int direction, int Gx_old, int Zx_old, int Gx, int Zx,
        int overlapping) {
    int Ex;
    /* only used with sequence pattern */
    switch (direction) {
            /* Northeast */
        case 1:
            /* east */
        case 2:
            /* southeast */
        case 3:
            Ex = Zx_old + Gx_old;
            if (overlapping)
                Ex = Ex - 2;
            Zx = Ex + Gx;
            break;
            /* southwest */
        case 5:
            /* west */
        case 6:
            /* northwest */
        case 7:
            Ex = Zx_old - Gx_old;
            if (overlapping)
                Ex = Ex + 2;
            Zx = Ex - Gx;
            break;
            /* north */
        case 0:
            /* south */
        case 4:
            Ex = Zx_old + Gx_old;
            Zx = Zx_old;
            break;
    }
    return (Zx);
}

int
Dimensiony(int direction, int Gy_old, int Zy_old, int Gy, int Zy,
        int overlapping) {
    int Ey;
    switch (direction) { /* only used with sequence pattern */
            /* east */
        case 2:
            /* west */
        case 6:
            Ey = Zy_old + Gy_old;
            Zy = Zy_old;
            break;
            /* southeast */
        case 3:
            /* south */
        case 4:
            /* southwest */
        case 5:
            Ey = Zy_old - Gy_old;
            if (overlapping)
                Ey = Ey + 2;
            Zy = Ey - Gy;
            break;
            /* north */
        case 0:
            /* northeast */
        case 1:
            /* northwest */
        case 7:
            Ey = Zy_old + Gy_old;
            if (overlapping)
                Ey = Ey - 2;
            Zy = Ey + Gy;
            break;
    }
    return (Zy);
}

/* pattern: nested, subpattern: inside without border overlapping */
void p1_subp1() {
    int Lxup, Lxdown, Lyup, Lydown;
    double szx, szy, srx;
    double llx, lly, urx, ury;
    int region;
    int noelements;
    int shape[4];
    int Zx[4], Zy[4];
    int Gx[4], Gy[4];
    int i, v;
    region = Pseudorand(); /* region definition */
    region = region % 9;
    regiondefinition(region, &Lxup, &Lxdown, &Lyup, &Lydown);
    noelements = Pseudorand(); /* Number of elements */
    noelements = (noelements % 4) + 1;
    shape[0] = 1;
    /* We use that Pseudorand returns a number between 1-100 */
    Zx[0] = Pseudorand(); /* center definition */
    Zx[0] = scale(Lxdown, Lxup, Zx[0]);
    /* We use that Pseudorand returns a number between 1-100 */
    Zy[0] = Pseudorand();
    Zy[0] = scale(Lydown, Lyup, Zy[0]);
    /* We use that Pseudorand returns a number between 1-100 */
    Gx[0] = Pseudorand(); /* size definition */
    Gx[0] = scale(6, 15, Gx[0]); /* first shape must be the biggest one */
    /* We use that Pseudorand returns a number between 1-100 */
    Gy[0] = Pseudorand();
    Gy[0] = scale(6, 15, Gy[0]);
    v = value(); /* value between 0 and 9900 */
    
    if (EXIT_FAILURE == ComputeRectangle(Zx[0], Zy[0], Gx[0], Gy[0], &llx, &lly, &urx, &ury))
    {
	    fprintf(stderr,"This should never happen! See bookmark <1>\n");
	    exit(EXIT_FAILURE);
    }
    /* write geometry to file */
    fprintf(diffusionfile, "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n", 'r', 
            llx, lly, urx, ury, v);
#ifdef DEBUGON
    fprintf(fcontrol, " %d \t %d \t %d \t %d \t %d \t %d \t", shape[0],
            Zx[0], Zy[0], Gx[0], Gy[0], v);
#endif
    for (i = 1; i < noelements; i++) {
	char pleasebreak=0;
     
        if (i == (noelements - 1)) { 
            /* In this pattern only the last element can be a circle */
            shape[i] = Pseudorand();
            shape[i] = shape[i] % 2;
        } else
            shape[i] = 1;

	/* set the size on 2/3 of the old size */
        Gx[i] = (int) (Gx[i - 1] / 1.5);
	if (Gx[i]==0) 
	{
	    Gx[i] = 1;
 	    pleasebreak=1;
	}
	/* set the size on 2/3 of the old size */
        Gy[i] = (int) (Gy[i - 1] / 1.5);
	if (Gy[i]==0) 
	{
	    Gy[i] = 1;
 	    pleasebreak=1;
	}	

        /* We use that Pseudorand returns a number between 1-100 */
        Zx[i] = Pseudorand(); /* center definition */
        Zx[i] =
                scale(Zx[i - 1] - (Gx[i - 1] / 1.5),
                Zx[i - 1] + (Gx[i - 1] / 1.5), Zx[i]);
        /* We use that Pseudorand returns a number between 1-100 */
        Zy[i] = Pseudorand();
        Zy[i] =
                scale(Zy[i - 1] - (Gy[i - 1] / 2),
                Zy[i - 1] + (Gy[i - 1] / 2), Zy[i]);
        v = value(); /* value between 0 and 9900 */
        if (shape[i] == 0) { /* write the geometry to file */
            if ( EXIT_SUCCESS == ComputeCircle(Zx[i], Zy[i], Gx[i], Gy[i], &szx, &szy,
                    &srx) )
		{
         	   fprintf(diffusionfile,
         	           "%c \t %4.2f\t %4.2f\t  %4.2f\t %d\n", 'c', szx,
         	           szy, srx, v);
#ifdef DEBUGON
         	   fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t ",
         	           shape[i], Zx[i], Zy[i], Gx[i], v);
#endif
		}	
        } else { /* write the geometry to file */
            if (EXIT_FAILURE == ComputeRectangle(Zx[i], Zy[i], Gx[i], Gy[i], &llx, &lly,
                    &urx, &ury))
	    {
	      fprintf(stderr,"This should never happen! See bookmark <2>\n");
	      exit(EXIT_FAILURE);
	    }
            fprintf(diffusionfile,
                    "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n",
                    'r', llx, lly, urx, ury, v);
#ifdef DEBUGON
            fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t %d\t",
                    shape[i], Zx[i], Zy[i], Gx[i], Gy[i], v);
#endif
        }
        if (pleasebreak == 1)
	{
	  break;
	} 
    }
}

/* pattern: nested, subpattern: inside with corner overlapping */
void p1_subp2() {
    int Lxup, Lxdown, Lyup, Lydown;
    double szx, szy, srx;
    double ulx, uly, orx, ory;
    int region;
    int noelements;
    int shape[4];
    int Zx[4], Zy[4];
    int Gx[4], Gy[4];
    int i, v;
    int Ex, Ey;
    region = Pseudorand(); /* region definition */
    region = region % 9;
    regiondefinition(region, &Lxup, &Lxdown, &Lyup, &Lydown);
    noelements = Pseudorand(); /* Number of elements */
    noelements = (noelements % 4) + 1;
    shape[0] = 1; /* first shape must be a rectangle */
    /* We use that Pseudorand returns a number between 1-100 */
    Zx[0] = Pseudorand(); /* center definition */
    Zx[0] = scale(Lxdown, Lxup, Zx[0]);
    /* We use that Pseudorand returns a number between 1-100 */
    Zy[0] = Pseudorand();
    Zy[0] = scale(Lydown, Lyup, Zy[0]);
    /* We use that Pseudorand returns a number between 1-100 */
    Gx[0] = Pseudorand(); /* size definition */
    Gx[0] = scale(6, 15, Gx[0]); /* first shape must be the biggest one */
    /* We use that Pseudorand returns a number between 1-100 */
    Gy[0] = Pseudorand();
    Gy[0] = scale(6, 15, Gy[0]);
    v = value(); /* value between 0 and 9900 */
    if (EXIT_FAILURE == ComputeRectangle(Zx[0], Zy[0], Gx[0], Gy[0], &ulx, &uly, &orx, &ory))
	    {
	      fprintf(stderr,"This should never happen! See bookmark <3>\n");
	      exit(EXIT_FAILURE);
	    }
    fprintf(diffusionfile, "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n",
            'r', ulx, uly, orx, ory, v);
#ifdef DEBUGON
    fprintf(fcontrol, " %d \t %d \t %d \t %d \t %d \t %d \t", shape[0],
            Zx[0], Zy[0], Gx[0], Gy[0], v);
#endif
    for (i = 1; i < noelements; i++) {
        if (i == (noelements - 1)) { 
            /* In this pattern only the last element can be a circle */
            shape[i] = Pseudorand();
            shape[i] = shape[i] % 2;
        } else
            shape[i] = 1;
        Ex = Zx[i - 1] - Gx[i - 1]; /* left corner */
        Ey = Zy[i - 1] - Gy[i - 1]; /* down corner */
        /* We use that Pseudorand returns a number between 1-100 */
        Gx[i] = Pseudorand(); /* size definition */
        Gx[i] = scale(2 * Gx[i - 1] / 3, Gx[i - 1] - 1, Gx[i]);
        /* We use that Pseudorand returns a number between 1-100 */
        Gy[i] = Pseudorand();
        Gy[i] = scale(2 * Gy[i - 1] / 3, Gy[i - 1] - 1, Gy[i]);
        Zx[i] = Gx[i] + Ex; /* center definition */
        Zy[i] = Gy[i] + Ey;
        v = value(); /* value between 0 and 9900 */
        if (shape[i] == 0) { /* write geometry to file */
            if ( EXIT_SUCCESS == ComputeCircle(Zx[i], Zy[i], Gx[i], Gy[i], &szx, &szy,
                    &srx)) 
		{
            fprintf(diffusionfile,
                    "%c \t %4.2f\t %4.2f\t  %4.2f\t %d\n", 'c', szx,
                    szy, srx, v);
#ifdef DEBUGON
            fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t ",
                    shape[i], Zx[i], Zy[i], Gx[i], v);
#endif
		}
        } else {
            if (EXIT_FAILURE == ComputeRectangle(Zx[i], Zy[i], Gx[i], Gy[i], &ulx, &uly,
                    &orx, &ory))
	    {
	      fprintf(stderr,"This should never happen! See bookmark <4>\n");
	      exit(EXIT_FAILURE);
	    }
            fprintf(diffusionfile,
                    "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n",
                    'r', ulx, uly, orx, ory, v);
#ifdef DEBUGON
            fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t %d\t",
                    shape[i], Zx[i], Zy[i], Gx[i], Gy[i], v);
#endif
        }
    }
}

void p1_subp3() /* pattern: nested, subpattern: inside with side overlapping */
{
  int Lxup, Lxdown, Lyup, Lydown;
  double szx, szy, srx;
  double ulx, uly, orx, ory;
  int region;
  int noelements;
  int shape[4];
  int Zx[4], Zy[4];
  int Gx[4], Gy[4];
  int i;
  int Ey;
  int v;
  region = Pseudorand(); /* /region definition */
  region = region % 9;
  regiondefinition(region, &Lxup, &Lxdown, &Lyup, &Lydown);
  noelements = Pseudorand(); /* Number of elements */
  noelements = (noelements % 4) + 1;
  shape[0] = 1; /* first shape muss be a rectangle */
  /* We use that Pseudorand returns a number between 1-100 */
  Zx[0] = Pseudorand(); /* center definition */
  Zx[0] = scale(Lxdown, Lxup, Zx[0]);
  /* We use that Pseudorand returns a number between 1-100 */
  Zy[0] = Pseudorand();
  Zy[0] = scale(Lydown, Lyup, Zy[0]);
  /* We use that Pseudorand returns a number between 1-100 */
  Gx[0] = Pseudorand(); /* size definition */
  Gx[0] = scale(6, 15, Gx[0]); /* first scale must be the biggest shape */
  /* We use that Pseudorand returns a number between 1-100 */
  Gy[0] = Pseudorand();
  Gy[0] = scale(6, 15, Gy[0]);
  v = value(); /* value between 0 and 9900 */
  if (EXIT_FAILURE == ComputeRectangle(Zx[0], Zy[0], Gx[0], Gy[0], &ulx, &uly, &orx, &ory))
    {
      fprintf(stderr,"This should never happen! See bookmark <5>\n");
      exit(EXIT_FAILURE);
    }
  fprintf(diffusionfile,
	  "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n", 'r', ulx,
	  uly, orx, ory, v);
#ifdef DEBUGON
  fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t %d\t",
	  shape[0], Zx[0], Zy[0], Gx[0], Gy[0], v);
#endif
  for (i = 1; i < noelements; i++) 
    { 
      char pleasebreak = 0;

      /*  In this pattern only the last element can be a circle */
      if (i == (noelements - 1)) {
	shape[i] = Pseudorand();
	shape[i] = shape[i] % 2;
      } else
	shape[i] = 1;
      Ey = Zy[i - 1] - Gy[i - 1]; /* down corner */
      
      Gx[i] = Gx[i - 1]/1.5;
      if (Gx[i] == 0)
	{
	  Gx[i]=1;
	  pleasebreak = 1;
	}

    /* We use that Pseudorand returns a number between 1-100 */
      Gy[i] = Pseudorand();
      Gy[i] = scale(2 * Gy[i - 1] / 3, Gy[i - 1] - 1, Gy[i]);
      /* We use that Pseudorand returns a number between 1-100 */
      Zx[i] = Pseudorand(); /* center definition */
      Zx[i] =
	scale(Zx[i - 1] - (Gx[i - 1] / 1.5),
	      Zx[i - 1] + (Gx[i - 1] / 1.5), Zx[i]);
      Zy[i] = Gy[i] + Ey;
      v = value();
      if (shape[i] == 0) { /* write geometry in file */
	if ( EXIT_SUCCESS == ComputeCircle(Zx[i], Zy[i], Gx[i], Gy[i], &szx,
					   &szy, &srx)) 
	  {
	    fprintf(diffusionfile,
		    "%c \t %4.2f\t %4.2f\t  %4.2f\t %d\n",
		    'c', szx, szy, srx, v);
#ifdef DEBUGON
	    fprintf(fcontrol,
		    "%d \t %d \t %d \t %d \t %d \t ",
		    shape[i], Zx[i], Zy[i], Gx[i], v);
#endif
	  }
      } 
      else {
	if (EXIT_FAILURE == ComputeRectangle(Zx[i], Zy[i], Gx[i], Gy[i],
					     &ulx, &uly, &orx, &ory))
	  {
	    fprintf(stderr,"This should never happen! See bookmark <6>\n");
	    exit(EXIT_FAILURE);
	  }
	fprintf(diffusionfile,
		"%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n",
		'r', ulx, uly, orx, ory, v);
#ifdef DEBUGON
	fprintf(fcontrol,
		"%d \t %d \t %d \t %d \t %d \t %d\t",
		shape[i], Zx[i], Zy[i], Gx[i], Gy[i],
		v);
#endif
      }
      if (pleasebreak == 1)
	{
	  break;
	}
    }
}

void pattern1() /* Pattern: nested */
{
    int subpattern;
    subpattern = Pseudorand(); /* subpattern definition */
    subpattern = subpattern % 3;
    switch (subpattern) {
        case 0: /* inside without border overlapping */
            p1_subp1();
            break;
        case 1: /* inside with corner overlapping */
            p1_subp2();
            break;
        case 2: /* inside with side overlapping */
            p1_subp3();
            break;
    }
}

void pattern2() /* Pattern: sequence */
{
    int Lxup, Lxdown, Lyup, Lydown;
    double szx, szy, srx;
    double ulx, uly, orx, ory;
    int region;
    int noelements;
    int shape[4];
    int Zx[4], Zy[4];
    int Gx[4], Gy[4];
    int direction;
    int overlapping;
    int i, v;
    region = Pseudorand(); /* region definition */
    region = region % 9;
    regiondefinition(region, &Lxup, &Lxdown, &Lyup, &Lydown);
    noelements = Pseudorand(); /* Number of elements */
    noelements = (noelements % 4) + 1;
    shape[0] = Pseudorand(); /* shape definition: circle=0 or rectangle=1 */
    shape[0] = shape[0] % 2;
    /* We use that Pseudorand returns a number between 1-100 */
    Zx[0] = Pseudorand(); /* center definition */
    Zx[0] = scale(Lxdown, Lxup, Zx[0]);
    /* We use that Pseudorand returns a number between 1-100 */
    Zy[0] = Pseudorand();
    Zy[0] = scale(Lydown, Lyup, Zy[0]);
    Gx[0] = Pseudorand(); /* size definition */
    Gx[0] = scale(3, 10, Gx[0]);
    Gy[0] = Pseudorand();
    Gy[0] = scale(3, 10, Gy[0]);
    v = value(); /* value between 0 and 9900 */
    if (shape[0] == 0) { /* write geometrie to file */
        if ( EXIT_SUCCESS == ComputeCircle(Zx[0], Zy[0], Gx[0], Gy[0], &szx, &szy, &srx))
{
        fprintf(diffusionfile, "%c \t %4.2f\t %4.2f\t  %4.2f\t %d\n",
                'c', szx, szy, srx, v);
#ifdef DEBUGON
        fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t ", shape[0],
                Zx[0], Zy[0], Gx[0], v);
#endif
	} 
   } else {
        if (EXIT_FAILURE == ComputeRectangle(Zx[0], Zy[0], Gx[0], Gy[0], &ulx, &uly, &orx,
                &ory))
	    {
	      fprintf(stderr,"This should never happen! See bookmark <7>\n");
	      exit(EXIT_FAILURE);
	    }
        fprintf(diffusionfile,
                "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n", 'r', ulx,
                uly, orx, ory, v);
#ifdef DEBUGON
        fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t %d \t ",
                shape[0], Zx[0], Zy[0], Gx[0], Gy[0], v);
#endif
    }
    for (i = 1; i < noelements; i++) {
        shape[i] = Pseudorand(); /* circle=0 or rectangle=1 */
        shape[i] = shape[i] % 2;
        direction = Pseudorand(); /* N,S,W,E,NE,SE,NW,SW */
        direction = direction % 7;
        overlapping = Pseudorand(); /* overlapping (yes/no) */
        overlapping = overlapping % 2;
        /* We use that Pseudorand returns a number between 1-100 */
        Gx[i] = Pseudorand(); /* size definition */
        Gx[i] = scale(3, 10, Gx[i]);
        /* We use that Pseudorand returns a number between 1-100 */
        Gy[i] = Pseudorand();
        Gy[i] = scale(3, 10, Gy[i]);
        /* center definition */
        Zx[i] = Dimensionx(direction, Gx[i - 1], Zx[i - 1], Gx[i], Zx[i],
                overlapping);
        Zy[i] =
                Dimensiony(direction, Gy[i - 1], Zy[i - 1], Gy[i], Zy[i],
                overlapping);
        v = value(); /* value between 0 and 9900 */
        if (shape[i] == 0) { /* write to file */
            if ( EXIT_SUCCESS == ComputeCircle(Zx[i], Zy[i], Gx[i], Gy[i], &szx, &szy,
                    &srx))
{
            fprintf(diffusionfile,
                    "%c \t %4.2f\t %4.2f\t  %4.2f\t %d\n", 'c', szx,
                    szy, srx, v);
#ifdef DEBUGON
            fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t ",
                    shape[i], Zx[i], Zy[i], Gx[i], v);
#endif
} 
       } else {
            if (EXIT_FAILURE == ComputeRectangle(Zx[i], Zy[i], Gx[i], Gy[i], &ulx, &uly,
                    &orx, &ory))
	    {
	      fprintf(stderr,"This should never happen! See bookmark <8>\n");
	      exit(EXIT_FAILURE);
	    }
            fprintf(diffusionfile,
                    "%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n",
                    'r', ulx, uly, orx, ory, v);
#ifdef DEBUGON
            fprintf(fcontrol, "%d \t %d \t %d \t %d \t %d \t %d\t",
                    shape[i], Zx[i], Zy[i], Gx[i], Gy[i], v);
#endif
        }
    }
}

/* Pattern:isolated, subpattern: isolated pseudorand */
void p3_subp1() {
    int Lxup, Lxdown, Lyup, Lydown;
    double szx, szy, srx;
    double ulx, uly, orx, ory;
    int region;
    int noelements;
    int shape[4];
    int Zx[4], Zy[4];
    int Gx[4], Gy[4];
    int overlapping = 0;
    int i = 0, j;
    int v;
    int DistanceZx = 0, DistanceZy = 0, DistanceGx = 0, DistanceGy = 0;
    region = Pseudorand(); /* region definition */
    region = region % 9;
    regiondefinition(region, &Lxup, &Lxdown, &Lyup, &Lydown);
    noelements = Pseudorand(); /* Number of elements */
    noelements = (noelements % 4) + 1; /* [1,2,3,4] */
    while (i < noelements) {
        overlapping = 0; /* initialize */
        shape[i] = Pseudorand(); /* shape definition: circle=0 or rectangle=1 */
        shape[i] = shape[i] % 2;
        Zx[i] = Pseudorand(); /* center definition for first shape in region */
        Zx[i] = scale(Lxdown, Lxup, Zx[i]);
        Zy[i] = Pseudorand();
        Zy[i] = scale(Lydown, Lyup, Zy[i]);
        if ((region == 5) || (region == 6) || (region == 7) || (region == 8)) { 
            /* small region, small shapes */
            /* We use that Pseudorand returns a number between 1-100 */
            Gx[i] = Pseudorand(); /* size definition */
            Gx[i] = scale(1, 3, Gx[i]);
            /* We use that Pseudorand returns a number between 1-100 */
            Gy[i] = Pseudorand();
            Gy[i] = scale(1, 3, Gy[i]);
        } else {
            /* We use that Pseudorand returns a number between 1-100 */
            Gx[i] = Pseudorand(); /* size definition */
            Gx[i] = scale(1, 5, Gx[i]);
            /* We use that Pseudorand returns a number between 1-100 */
            Gy[i] = Pseudorand();
            Gy[i] = scale(1, 5, Gy[i]);
        }
        /* overlapping? */
        for (j = 1; j <= i; j++) {
            DistanceZx = abs(Zx[i] - Zx[i - j]);
            DistanceZy = abs(Zy[i] - Zy[i - j]);
            DistanceGx = Gx[i] + Gx[i - j];
            DistanceGy = Gy[i] + Gy[i - j];
            if ((DistanceZx < DistanceGx) && (DistanceZy < DistanceGy)) { 
                /* overlapping */
                overlapping = 1;
                j = i + 1;
            }
        }

        if (overlapping == 0) { /* correct shape */
		
            if ( (EXIT_SUCCESS == ComputeCircle(Zx[i], Zy[i], Gx[i], Gy[i], &szx, &szy,&srx) ) && 
		  (EXIT_SUCCESS == ComputeRectangle(Zx[i], Zy[i], Gx[i], Gy[i], &ulx, &uly,&orx, &ory)) )
	    {
		v = value();
		if (shape[i] == 0) { /* write to file */
#ifdef DEBUGON
			fprintf(fcontrol,
				"%d \t %d \t %d \t %d \t  %d \t ",
				shape[i], Zx[i], Zy[i], Gx[i], v);
#endif
			fprintf(diffusionfile,
				"%c \t %4.2f\t %4.2f\t  %4.2f\t %d\n",
				'c', szx, szy, srx, v);

		} else {
#ifdef DEBUGON
			fprintf(fcontrol,
				"%d \t %d \t %d \t %d \t %d \t %d \t ",
				shape[i], Zx[i], Zy[i], Gx[i], Gy[i],
				v);
#endif
			fprintf(diffusionfile,
				"%c \t %4.2f\t %4.2f\t %4.2f\t %4.2f\t %d\n",
				'r', ulx, uly, orx, ory, v);
		}
		i = i + 1;
	}
        }
    }
}

void p3_subp2() /* not used */
{
}

void pattern3() /* Pattern: isolated */
{
    int subpattern;
    subpattern = Pseudorand(); /* subpattern definition */
    subpattern = subpattern % 2;
    subpattern = 0; /* in this implementation, only subpattern 0 is posible */
    switch (subpattern) {
        case 0: /* isolated pseudorand */
            p3_subp1();
            break;
        case 1: /* isolated in subgrid */
            p3_subp2();
            break;
    }
}

int main(int argc, char *const argv[]) {
    int GeneratedTestCases = 100;
    /*int GeneratedTestCasesDigits;*/ /* i.e.: "100" is 3 digits. */
    int i, j;
    int pattern;
    int nopattern;
    char filename[100];
    /*char digits[100];*/

    if (argc > 1) {
        GeneratedTestCases = atoi(argv[1]);
        if (GeneratedTestCases <= 0) {
            fprintf(stderr,
                    "Please enter a natural number bigger than zero!\n");
            return (EXIT_FAILURE);
        }
    }

    /*GeneratedTestCasesDigits = sprintf(digits, "%d", GeneratedTestCases);*/

    PseudorandInit();
#ifdef DEBUGON
    fcontrol = fopen("combinations.txt", "w");
#endif
    for (i = 1; i <= GeneratedTestCases; i++) /* start geometry generation */
    {
        nopattern = Pseudorand(); /* number of pattern */
        nopattern = nopattern % 3 + 1;
        /*sprintf(filename, "output/diffusion.%0*d.txt", GeneratedTestCasesDigits, i);*/
        sprintf(filename, "output/diffusion.%06d.txt", i);
        diffusionfile = fopen(filename, "w");
        for (j = 1; j <= nopattern; j++) {
            pattern = Pseudorand(); /* pattern definition */
            pattern = pattern % 3;
            switch (pattern) {
                case 0: /* nested */
                    pattern1();
                    break;
                case 1: /* sequence */
                    pattern2();
                    break;
                case 2: /* isolated */
                    pattern3();
                    break;
            }
        }
        fclose(diffusionfile);
#ifdef DEBUGON
        fprintf(fcontrol, "\n");
#endif
    }
#ifdef DEBUGON
    fclose(fcontrol);
#endif
    return (EXIT_SUCCESS);
}
