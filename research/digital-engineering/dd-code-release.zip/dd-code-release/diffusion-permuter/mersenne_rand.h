#ifndef _MERSENNE_RAND_H
#define _MERSENNE_RAND_H

#include <stdint.h>

/* initialize the Mersenne Twister PRNG with seed */
void mt_init(uint32_t seed);

/* extract a pseudorandom number from the PRNG */
uint32_t mt_random();

#endif
